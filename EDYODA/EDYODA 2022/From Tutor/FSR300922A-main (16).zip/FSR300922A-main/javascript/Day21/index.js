var number_of_apples = 10;

var fullName = "Utkarsh Gupta";

var CountryName = "India";

var NUMBER_OF_STATES = 29;

var a = 10;
var A = 10;
var numberOfStates = 29;

var andj233$di = "djiv";

var x = 10;
var y = 20;

var sum;

sum = x + y;

sum = x - y;

sum = x * y;

sum = y / x;

sum = y % x;

false || false || true;
//true

true && false;
// false

if (true && false) {
}

for (var x = 0; x < 4; x++) {}
