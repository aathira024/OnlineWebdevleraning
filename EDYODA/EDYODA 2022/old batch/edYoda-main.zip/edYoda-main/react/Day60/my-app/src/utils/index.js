const log = (...args) => {
  console.log(...args);
};
const validateForm = () => {};

const showError = (message) => {
  console.error(message);
};
export { log, validateForm };

export default showError;
