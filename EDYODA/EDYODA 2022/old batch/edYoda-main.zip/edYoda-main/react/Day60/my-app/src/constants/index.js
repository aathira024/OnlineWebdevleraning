export const data = [
  {
    id: 699,
    firstName: "Ralph",
    lastName: "Towers",
    email: "JBunch@lorem.gov",
    phone: "(459)796-1165",
    image: "https://randomuser.me/api/portraits/men/19.jpg",
    address: {
      streetAddress: "3827 Odio St",
      city: "Swansea",
      state: "VA",
      zip: "30659",
    },
    description:
      "facilisis ante eros porttitor sed ante sed amet libero aliquam nec adipiscing sed libero tortor ante sollicitudin aliquam donec malesuada dolor sagittis pharetra vitae sed ac odio velit amet molestie etiam risus",
  },
  {
    id: 508,
    firstName: "Hathor",
    lastName: "Eichberger",
    email: "LHarkema@tellus.gov",
    phone: "(252)427-3920",
    image: "https://randomuser.me/api/portraits/men/20.jpg",
    address: {
      streetAddress: "1899 Pretium Ln",
      city: "Mooresville",
      state: "NE",
      zip: "87041",
    },
    description:
      "facilisis sed curabitur ipsum sollicitudin magna donec tellus elit sed magna donec libero dui consequat dui id risus sit hendrerit ante malesuada lectus etiam sit nec aliquam dolor porta sit nunc dolor",
  },
  {
    id: 632399,
    firstName: "Kite",
    lastName: "Towers",
    email: "JBunch@lorem.gov",
    phone: "(459)796-1165",
    image: "https://randomuser.me/api/portraits/men/21.jpg",
    address: {
      streetAddress: "3827 Odio St",
      city: "Swansea",
      state: "VA",
      zip: "30659",
    },
    description:
      "facilisis ante eros porttitor sed ante sed amet libero aliquam nec adipiscing sed libero tortor ante sollicitudin aliquam donec malesuada dolor sagittis pharetra vitae sed ac odio velit amet molestie etiam risus",
  },
  {
    id: 6323199,
    firstName: "Simba",
    lastName: "Towers",
    email: "JBunch@lorem.gov",
    phone: "(459)796-1165",
    image: "https://randomuser.me/api/portraits/men/22.jpg",
    address: {
      streetAddress: "3827 Odio St",
      city: "Swansea",
      state: "VA",
      zip: "30659",
    },
    description:
      "facilisis ante eros porttitor sed ante sed amet libero aliquam nec adipiscing sed libero tortor ante sollicitudin aliquam donec malesuada dolor sagittis pharetra vitae sed ac odio velit amet molestie etiam risus",
  },
];
