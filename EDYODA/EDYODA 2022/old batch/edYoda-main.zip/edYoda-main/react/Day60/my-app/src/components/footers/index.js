import React from "react";
import style from "./footer.module.css";

const Footer = () => {
  return <footer className={style.footer}>I love tinder ❤️</footer>;
};

export default Footer;
