import React from "react";
import Footer from "../../components/footers";
import Header from "../../components/headers";

const About = () => {
  return (
    <div>
      <Header />

      <Footer />
    </div>
  );
};

export default About;
