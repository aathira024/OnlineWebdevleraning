export const BASE_URL = "https://reqres.in/api";

export const END_POINTS = {
  getUsers: "/users",
  registerUSer: "/register",
};
