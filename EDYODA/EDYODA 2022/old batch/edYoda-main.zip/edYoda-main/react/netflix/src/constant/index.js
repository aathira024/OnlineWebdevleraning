const popular = [
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p1.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p2.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p3.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p4.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p5.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true",
  },
];

const trendings = [
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p7.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p8.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p9.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p10.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p11.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p12.PNG?raw=true",
  },
];

const shows = [
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p1.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p2.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p3.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p4.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p5.PNG?raw=true",
  },
  {
    id: "fhdifje",
    image:
      "https://github.com/carlosavilae/Netflix-Clone/blob/master/img/p6.PNG?raw=true",
  },
];

export { popular, trendings, shows };
