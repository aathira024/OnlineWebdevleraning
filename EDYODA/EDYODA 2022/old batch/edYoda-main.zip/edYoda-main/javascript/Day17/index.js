var num1; // undefined
var num2;
var num3;

num1 = 3;
num2 = 5;
num3 = 10;

var name = "Utkarsh";

// Rules:

var a = "Any random string type data";
var A = "Any random string type data";

//camel case

var totalSum = 102;

var myLastName = "Gupta";

// Pascal Case

var MyFirstName = "Utkarsh";

// Snake Case

var my_mother_name = "Mother Name";

var object = 2; // whereas Object is reserved keyword

//Arithmetic Operators

var num1 = 10;
var num2 = 2;

var sum = num1 + num2; // 12

var sub = num1 - num2; //8

var mul = num1 * num2; // 20

var div = num1 / num2; // 5

var remainder = num1 % num2; // 0

// Equal symbols
