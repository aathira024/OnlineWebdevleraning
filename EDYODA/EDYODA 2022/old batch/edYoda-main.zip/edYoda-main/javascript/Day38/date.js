const date = new Date();

console.log(date.getDate());
console.log(date.getMonth() + 1);
console.log(date.getFullYear());
const time = date.getTime();
